import turtle

screen = turtle.Screen()
screen.setup(width=600, height=600)
screen.bgcolor("black")
screen.title("Snake Game")

starting_position = [(0, 0), (-20, 0), (-40, 0)]
screen.tracer(0)

for position in starting_position:
    body_segment = turtle.Turtle(shape="square")
    body_segment.color("white")
    body_segment.goto(position)
    screen.update()


screen.exitonclick()
