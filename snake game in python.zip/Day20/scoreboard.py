from turtle import Turtle
ALIGN = "center"
FONT = ("Algerian", 24, "normal")


class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.score = 0
        with open("data.txt") as high_score_stored:
            self.high_score = int(high_score_stored.read())
        self.color("white")
        self.penup()
        self.goto(x=0, y=265)
        self.hideturtle()
        self.display_score()

    def display_score(self):
        self.clear()
        self.write(f"Score : {self.score}, HighScore : {self.high_score}", align=ALIGN, font=FONT)

    def reset(self):
        if self.score > self.high_score:
            self.high_score = self.score
            with open("data.txt", mode="w") as high_score_stored:
                high_score_stored.write(str(self.high_score))
        self.score = 0
        self.display_score()

    def increase_score(self):
        self.score += 1
        self.display_score()
