import turtle
import time
from snake import Snake
from food import Food
from scoreboard import Scoreboard

time.sleep(1)
screen = turtle.Screen()
screen.setup(width=600, height=600)
screen.bgcolor("black")
screen.title("Snake Game")
screen.tracer(0)

level = screen.textinput("Level", "Select a level by typing |easy|, |normal| or |hard|").lower()

snake = Snake()
food = Food()
score = Scoreboard()

screen.listen()
screen.onkey(snake.up, "Up")
screen.onkey(snake.down, "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")

game_is_on = True


while game_is_on:
    if level == "hard":
        time.sleep(0.05)
    elif level == "normal":
        time.sleep(0.1)
    elif level == "easy":
        time.sleep(0.2)
    else:
        pass

    screen.update()
    snake.move()

#     Colliding with the food
    if snake.segments[0].distance(food) < 15:
        food.refresh()
        snake.extend()
        score.increase_score()

#     Detect to colliding with the Wall
    if snake.segments[0].xcor() > 295 or snake.segments[0].xcor() < -295 or \
            snake.segments[0].ycor() > 295 or snake.segments[0].ycor() < -295:
        score.reset()
        snake.reset()

#     Detect the collision with tail of the snake.
    for segment in snake.segments[1:]:
        if segment == snake.segments[0]:
            pass
        elif snake.segments[0].distance(segment) < 5:
            score.reset()
            snake.reset()


screen.exitonclick()
